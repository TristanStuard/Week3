# Get input from the user
hourly_wage = float(input("Enter the hourly wage: "))
total_regular_hours = float(input("Enter the total regular hours: "))
total_overtime_hours = float(input("Enter the total overtime hours: "))

# Calculate regular pay
regular_pay = hourly_wage * total_regular_hours

# Calculate overtime pay
overtime_pay = hourly_wage * 1.5 * total_overtime_hours

# Calculate total weekly pay
total_pay = regular_pay + overtime_pay

# Display the employee's total weekly pay
print("Total weekly pay:", total_pay)
