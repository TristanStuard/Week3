# Tax Calculator

# Get input from the user
income = float(input("Enter your income: "))

# Calculate the tax amount
tax = income * 0.1  # Assuming a 10% tax rate

# Round the tax amount to two digits of precision
rounded_tax = round(tax, 2)

# Display the rounded tax amount
print("Tax amount:", rounded_tax)
