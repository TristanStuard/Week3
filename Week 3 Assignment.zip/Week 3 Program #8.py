# Constants
SPEED_OF_LIGHT = 3 * 10**8  # meters per second
SECONDS_IN_YEAR = 365 * 24 * 60 * 60  # seconds

# Calculate the distance in meters
distance = SPEED_OF_LIGHT * SECONDS_IN_YEAR

# Display the value of a light-year
print("A light-year is approximately", distance, "meters.")
